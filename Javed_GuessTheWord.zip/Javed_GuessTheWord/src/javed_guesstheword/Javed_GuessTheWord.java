/*
 Ahlam Javed
ITDEV-110
Hangman assignment #9
 */
package javed_guesstheword;

/**
 *
 * @author JAVEDAS1
 */
public class Javed_GuessTheWord {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Controller controller = new Controller();
        
        controller.Start();
        controller.playMultiple();
    }
}
    
